/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carro;

/**
 *
 * @author Felipe
 */
public class Vehiculo {

    public String getCarro() {
        return carro;
        
    }

    public void setCarro(String carro) {
        this.carro = carro;
    }
    
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    public int getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(int kilometraje) {
        this.kilometraje = kilometraje;
    }
    

        

    String carro, color ;
     int kilometraje;
}  
  
